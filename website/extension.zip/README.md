# Installation
1. Decompress archive
2. Go to `chrome://extensions`
3. Enable developer mode
4. "Load Unpacked" extension
5. Point at decompressed archive